import 'package:flutter/material.dart';

class AboutPage extends StatelessWidget {
  const AboutPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFFF5FA),
      appBar: AppBar(
        title: const Text("About"),
        backgroundColor: Colors.pink,
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [

            //bo hamw devicek size rasmaka gunjaw be
            Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(
                  maxWidth: 900,
                  maxHeight: 350,
                ),
                child: AspectRatio(
                  aspectRatio: 16 / 9,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(20),
                    child: Image.asset(
                      'images/a.jpg',
                      fit: BoxFit.cover,
                      width: double.infinity,
                    ),
                  ),
                ),
              ),
            ),

            const SizedBox(height: 20),

            const Text(
              "About This Application",
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Color.fromARGB(255, 171, 10, 83),
              ),
            ),

            const SizedBox(height: 20),

            _infoCard(
              title: "What is this application?",
              icon: Icons.info_outline,
              content:
                  "This application helps users manage tasks, access features, "
                  "and perform daily activities efficiently.",
            ),

            _infoCard(
              title: "How to use the application",
              icon: Icons.touch_app,
              content:
                  "• Navigate using the main menu\n"
                  "• Customize settings like Dark Mode\n"
                  "• Complete tasks quickly\n"
                  "• Learn more from About section",
            ),

            _infoCard(
              title: "Goal of this application",
              icon: Icons.flag_outlined,
              content:
                  "To simplify workflows, improve productivity, and "
                  "deliver a smooth modern experience.",
            ),

            const SizedBox(height: 24),

            const Text(
              "Version 1.0.0",
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.grey),
            ),
          ],
        ),
      ),
    );
  }
//helper methoda drwst krdni card w icon w title w descriptiona
//statica chunka atwani bangi kaitawa ba be drwst krdni obj la naw stateless esh aka
  static Widget _infoCard({
    required String title,
    required IconData icon,
    required String content,
  }) {
    return Card(
      // 4 = depth shadowy cardakaia
      elevation: 4,
      margin: const EdgeInsets.only(bottom: 16),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(14),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, color: Colors.pink),
                const SizedBox(width: 8),
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w600,
                    color: Colors.pink,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Text(content, style: const TextStyle(fontSize: 15)),
          ],
        ),
      ),
    );
  }
}
