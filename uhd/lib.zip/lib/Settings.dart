import 'package:flutter/material.dart';
import 'package:uhd/Login_Screen.dart';
import 'package:uhd/main.dart';

class Settings extends StatefulWidget {
  Settings({Key? key}) : super(key: key);

  @override
  State<Settings> createState() => _SettingsState();
}

class _SettingsState extends State<Settings> {
  bool notificationsEnabled = true;
  bool darkMode = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Settings')),
      body: ListView(
        children: [
          SwitchListTile(
            title: Text('Enable Notifications'),
            subtitle: Text('Turn medicine reminders on/off'),
            value: notificationsEnabled,
            onChanged: (value) {
              setState(() {
                notificationsEnabled = value;
              
                   ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: Column(
                                      children: [
                                        Icon(
                                          notificationsEnabled
                                              ? Icons.notifications_active
                                              : Icons.notifications_off,
                                          size: 20,
                                          color: Colors.white,

                                        ),
                                        Text(
                                            notificationsEnabled
                                                ? 'Notifications Enabled'
                                                : 'Notifications Disabled',
                                        ),
                                      ],
                                    ),
                                  ),
                                );
              });
            },
            secondary: Icon(Icons.notifications),
            
          ),
          

          SwitchListTile(
            title: Text('Dark Mode'),
            subtitle: Text('Better for night use'),
            value: themeNotifier.value == ThemeMode.dark,
            onChanged: (bool value) {
              setState(() {
                themeNotifier.value = value ? ThemeMode.dark : ThemeMode.light;
              });
            },
            secondary: Icon(Icons.dark_mode),
          ),

          Divider(),

          ListTile(
            leading: Icon(Icons.language),
            title: Text('Language'),
            subtitle: Text('Change app language'),
            trailing: Icon(Icons.arrow_forward_ios),
            onTap: () {
              // دایەلۆگ بۆکسی گۆڕینی زمان
              showDialog(
                context: context,
                builder: (BuildContext context) {
                  String selectedLanguage = 'English';
                  return StatefulBuilder(
                    builder: (context, setState) {
                      return AlertDialog(
                        title: Text('Select Language'),
                        content: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            RadioListTile<String>(
                              title: Text('English'),
                              value: 'English',
                              groupValue: selectedLanguage,
                              onChanged: (value) {
                                setState(() {
                                  selectedLanguage = value!;
                                });
                              },
                            ),
                            RadioListTile<String>(
                              title: Text('کوردی'),
                              value: 'Kurdish',
                              groupValue: selectedLanguage,
                              onChanged: (value) {
                                setState(() {
                                  selectedLanguage = value!;
                                });
                              },
                            ),
                            RadioListTile<String>(
                              title: Text('عربي'),
                              value: 'Arabic',
                              groupValue: selectedLanguage,
                              onChanged: (value) {
                                setState(() {
                                  selectedLanguage = value!;
                                });
                              },
                            ),
                          ],
                        ),
                        actions: [
                          TextButton(
                            onPressed: () => Navigator.pop(context),
                            child: Text('Cancel'),
                          ),
                          TextButton(
                            onPressed: () {
                              Navigator.pop(context);
                            },
                            child: Text('Apply'),
                          ),
                        ],
                      );
                    },
                  );
                },
              );
            },
          ),

          ListTile(
            leading: const Icon(Icons.logout, color: Colors.red),
            title: const Text('Logout', style: TextStyle(color: Colors.red)),
            onTap: () {
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => LoginScreen()),
              );
            },
          ),
        ],
      ),
    );
  }
}
