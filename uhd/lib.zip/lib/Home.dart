import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:uhd/ContactUs.dart';
import 'package:uhd/Help.dart';
import 'package:uhd/Settings.dart';

//
// درووستکردنی کڵاسێك بۆ دەرمانەکان(ئایدییەکەی، ناوەکەی، کاتی خواردنەکەی)
// ئایدییەکەی بەس بۆ کاتی سڕینەوەی بەکار ئەهێنین، جگە لەوە پێویستمان بە ئایدی نییە
class MedicationReminder {
  final int id;
  String name;
  TimeOfDay time;
  final String? notes;

  MedicationReminder({
    required this.id,
    required this.name,
    required this.time,
    this.notes,
  });
}

class HomePage extends StatefulWidget {
  final String userName;
  HomePage({Key? key, required this.userName}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  
  //
  // هەموو ئەو دەرمان و کاتانەی زیادیان ئەکەین ئەبێت بە شێوازی لیست هەڵیبگرین
  // ئەگەر بە شێوازی لیست نەبێت ناتوانیت زیاد لە دانەیەك زیاد بکەیت
  // وەك ئەرەی لیستەکەی جاڤا
  List<MedicationReminder> _reminders = [];

  // میذۆدی زیاد کردن کە  پارامیتەرەکانی ناوی دەرمان و کاتی خواردنی تیایە
  void _addMedicine(String name, String timeStr, String notes) {
    try {
      // بۆ وەرگرتنی کاتەکە بە شێوازی Hour:Minute
      final parts = timeStr.split(':');

      // ئەمەیان تەنها سەعاتەکە وەرەگرێت و ئەیخاتە بەشی یەکەمی parts کە لە سەرەوە دروست کراوە
      int hour = int.parse(parts[0]);

      // ئەمەیان تەنها خولەکەکە وەرەگرێت و ئەیخاتە بەشی دووەمی parts کە لە سەرەوە دروست کراوە
      int minute = int.parse(parts[1]);

      // بۆ ڕێگری کردن لە داغڵکردنی کاتی هەڵە
      // بەم جۆرەیە:  ئەگەر سەعات بچووکتر بوو لە سفر، یان گەورەتر بوو  لە ٢٣
      // یان خولەك بچووکتر بوو لە سفر یان گەورەتر بوو لە ٥٩
      if (hour < 0 || hour > 23 || minute < 0 || minute > 59) {
        //
        // ئەوا ئەم ئیرۆر مەسجە پیشانبە لە سناك باڕ
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error: Hour must be 0 to 23 and Minute 0 to 59.'),
            backgroundColor: Colors.red,
          ),
        );
        return;
      }
      setState(() {
        // زیادکردنی دەرمانەکە بۆ لیستەکە
        // add خۆی میذۆدی حازری دارتە بۆ زیادکردنی ئایتمێك بۆ لیست
        _reminders.add(
          // کۆنسترەکتەری کڵاسی MedicationReminder ـە
          MedicationReminder(
            // درووست کردنی ئایدییەك کە بە پێی چرکەی درووستکردنی ئایتمەکە دایئەنێت
            id: DateTime.now().second,
            name: name,
            // درووستکردنی کاتەکە
            // سەعاتەکەی لە سەرەوە درووستمان کرد ئەخاتە Hour
            //و خولەکەکەش ئەخاتە Minuteـەوە
            time: TimeOfDay(hour: hour, minute: minute),
            notes: notes.isNotEmpty == true ? notes : null,
          ),
        );
      });
    } catch (e) {
      // هەر ئیرۆرێکی تر ڕوویدا ئەوا لە کۆنسوڵا پیشانیبە
      print(e);
    }
  }

  // میذۆدی سڕینەوەی ئایتمێك لە لیستەکە
  void _deleteMedicine(int id) {
    setState(() {
      // سڕینەوەی دەرمانەکە لە لیستەکە بە پێی ئایدی
      _reminders.removeWhere((reminder) => reminder.id == id);
    });
  }
 Future<void> confirmDelete(BuildContext context, int id) async {
    bool? result = await showDialog<bool>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text("Confirm Delete"),
          content: const Text("Are you sure you want to delete this reminder?"),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(false);
              },
              child: const Text("Cancel"),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
              ),
              onPressed: () {
                Navigator.of(context).pop(true);
              },
              child: const Text("Delete"),
            ),
          ],
        );
      },
    );

    if (result == true) {
      _deleteMedicine(id);
    }
  }

  // میذۆدی دەستکاری کردنی ئایتمێك

  void _editMedicine(MedicationReminder reminder) {
    final TextEditingController nameController = TextEditingController(
      text: reminder.name,
    );

    final TextEditingController timeController = TextEditingController(
      text:
          '${reminder.time.hour.toString().padLeft(2, '0')}:${reminder.time.minute.toString().padLeft(2, '0')}',
    );
    final TextEditingController noteController = TextEditingController();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (context) {
        return Padding(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(context).viewInsets.bottom,
            left: 16,
            right: 16,
            top: 16,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'Edit Medicine',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
              ),
              SizedBox(height: 12),
              TextField(
                controller: nameController,
                decoration: InputDecoration(
                  labelText: 'Medicine Name',
                  border: OutlineInputBorder(),
                ),
              ),
              SizedBox(height: 12),
              TextField(
                controller: timeController,
                decoration: InputDecoration(
                  labelText: 'Time (HH:MM)',
                  border: OutlineInputBorder(),
                ),
              ),
              SizedBox(height: 12),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: Text('Cancel'),
                  ),
                  ElevatedButton(
                    onPressed: () {
                      final name = nameController.text.trim();
                      final time = timeController.text.trim();

                      if (name.isNotEmpty && time.contains(':')) {
                        final parts = time.split(':');
                        final hour = int.parse(parts[0]);
                        final minute = int.parse(parts[1]);

                        if (hour >= 0 &&
                            hour <= 23 &&
                            minute >= 0 &&
                            minute <= 59) {
                          setState(() {
                            reminder.name = name;
                            reminder.time = TimeOfDay(
                              hour: hour,
                              minute: minute,
                            );
                          });
                          Navigator.pop(context);
                        }
                      }
                    },
                    child: Text('Update'),
                  ),
                ],
              ),
              SizedBox(height: 10),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      //
      // بەدیەکە ئەخاتە پشتی ئاپباڕەکە و ڕەنگی باگراوندەکەی ئەکات بە ڕەنگی ئاویی
      extendBodyBehindAppBar: true,
      backgroundColor: Colors.transparent,
      //
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: BoxDecoration(color: Colors.blueGrey),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    'Welcome, ${widget.userName}!',
                    style: TextStyle(color: Colors.white, fontSize: 24),
                  ),
                ],
              ),
            ),
            ListTile(
              leading: Icon(Icons.settings),
              title: Text('Settings'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => Settings()),
                );
              },
            ),
            ListTile(
              leading: Icon(Icons.contact_mail),
              title: Text('Contact Us'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => ContactUsPage()),
                );
              },
            ),
            ListTile(
              leading: Icon(Icons.help),
              title: Text('Help'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => HelpPage()),
                );
              },
            ),
          ],
        ),
      ),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        title: Text('MedReminder'),
        //
        //گۆڕینی ڕەنگی بەتنی دراوەرەکە
        iconTheme: IconThemeData(color: Colors.white),
        //
        titleTextStyle: TextStyle(
          color: Colors.white,
          fontSize: 20,
          fontWeight: FontWeight.w600,
        ),
      ),
      body: Container(
        //
        //بۆ تێکەڵکردنی ڕەنگی باگراوند
        // بۆ پشتی ئاپباڕەکە و بەدییەکە
        // ...
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            // بۆ بینینی کاریگەرییەکەی ئەم ڕەنگە ڕەشە بگۆڕە
            colors: Theme.of(context).brightness == Brightness.dark
                ? [Colors.blue, Colors.blueGrey[900]!]
                : [Colors.blueGrey, Colors.blueGrey[300]!],
          ),
        ),

        // SafeArea بۆ ڕیگری کردن لە تێکەڵ بوونی ئاپبار و بەدی
        // لە کاتی بردنە دواوەی بەدی بۆ پشتی ئاپباڕ
        child: SafeArea(
          child: Center(
            child: Container(
              child: Padding(
                padding: EdgeInsets.all(16),
                child: Material(
                  elevation: 8,
                  borderRadius: BorderRadius.circular(20),
                  color: Theme.of(context).brightness == Brightness.dark
                      ? Colors.blueGrey[700]
                      : Colors.blueGrey[100],
                  child: Padding(
                    padding: EdgeInsets.all(16),
                    child: Column(
                      children: [
                        Row(
                          children: [
                            Container(
                              //
                              // ئەم دیکۆرەیشنە بۆ بازنەکەی پشتی ئایکۆنەکەیە
                              decoration: BoxDecoration(
                                color: Colors.blueGrey[200],
                                shape: BoxShape.circle,
                              ),
                              //
                              padding: EdgeInsets.all(12),
                              child: Icon(
                                Icons.medical_services,
                                color: Colors.blueGrey,
                                size: 28,
                              ),
                            ),
                            SizedBox(width: 12),
                            Text(
                              'My Reminders',
                              style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.w700,
                                color:
                                    Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? Colors.white
                                    : Colors.blueGrey[900],
                              ),
                            ),

                          
                          ],
                        ),
                        SizedBox(height: 12),
                        Container(
                          height: 300,
                          alignment: Alignment.center,
                          //
                          // ئەگەر لیستەکە بەتاڵ بوو ئەوا ئەم تێکستە پیشانبە
                          child: _reminders.isEmpty
                              ? Text(
                                  'No reminders yet.\nTap + to add one.',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(color: Colors.grey[700]),
                                )
                              //
                              // بەڵام ئەگەر لیستەکە ئایتمێکی تیابوو ئەوا:
                              : ListView.builder(
                                  //
                                  // سەرەتا سەیری لیستەکە ئەکات بزانێت چەن ئایتمی تیایە
                                  itemCount: _reminders.length,
                                  //
                                  // دواتر هەموو ئایتمەکانی ناو لیستەکە لە ئیندێکسی سفرەوە
                                  // بانگ ئەکات
                                  itemBuilder: (context, i) {
                                    // نرخەکانی هەر ئایتمێك وەرەگرێت بە پێی ئیندێکسی ئایتمەکە
                                    //وەك: (ئایدی، ناو، کاتی وەرگرتن)
                                    // دواتر دەیخاتە ناو ڤاریەبڵی ئایتمس
                                    final items = _reminders[i];
                                    // بەشێوەی لیست ئەیگەڕێنێتەوە
                                    return ListTile(
                                      //
                                      // تایتڵ: ناوی دەرمانەکە وەرەگرێت لە لیستەکەوە
                                      title: Text(
                                        items.name,
                                        style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 19,
                                        ),
                                      ),
                                      //
                                      // سەب تایتڵ: کاتی خواردنی دەرمانەکە وەرەگرێت لە لیستەکەوە
                                      subtitle: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            items.time.format(context),
                                            style: TextStyle(
                                              fontWeight: FontWeight.bold,
                                              fontSize: 14,
                                            ),
                                          ),

                                          //
                                          //
                                          // new
                                          if (items.notes != null &&
                                              items.notes!.isNotEmpty)
                                            Text(
                                              items.notes!,
                                              style: TextStyle(
                                                fontStyle: FontStyle.italic,
                                                color: Colors.grey[600],
                                                fontSize: 16,
                                              ),
                                            ),
                                          //
                                          //
                                        ],
                                      ),

                                      //
                                      // سڕینەوەی ئایتمێک لە لیستەکە
                                      
                                      trailing: Wrap(
                                        spacing: 12,
                                        children: [
                                          IconButton(
                                            icon: Icon(
                                              Icons.edit,
                                              color: Colors.green,
                                            ),
                                            onPressed: () {
                                              _editMedicine(items);
                                            },
                                          ),
                                          IconButton(
                                            icon: Icon(
                                              Icons.delete,
                                              color: Colors.red,
                                            ),
                                            onPressed: () {
                                              confirmDelete(context, items.id);
                                            },
                                          ),
                                          //
                                        ],
                                      ),
                                    );
                                  },
                                ),

                          //
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),

      floatingActionButton: Container(
        margin: EdgeInsets.all(10),
        child: FloatingActionButton(
          backgroundColor: Colors.blueGrey[300],
          onPressed: () {
            // ئەمە وەکو بۆکسێکی بچووکە کە لە خوارەوەی شاشەکە دەرەکەوێت
            showModalBottomSheet(
              //
              // ئەم دێڕە واتا بۆکسەکە هەر لەم پەیجەیا پیشانبە نەك لە پەیجێکی ترا
              context: context,
              //
              isScrollControlled: true,
              //
              // قەوس کردنەوەی سوچەکانی سەرەوەی بۆکسەکە
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
              ),
              //
              builder: (context) {
                // کۆنترۆڵەر بۆ وەرگرتنی دەیتای ناو تێکست فیڵدەکە
                final TextEditingController nameController =
                    TextEditingController();
                final TextEditingController timeController =
                    TextEditingController();
                final TextEditingController noteController =
                    TextEditingController();
                //
                return Padding(
                  padding: EdgeInsets.only(
                    bottom: MediaQuery.of(context).viewInsets.left,
                    left: 16,
                    right: 16,
                    top: 16,
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        'Add Medicine',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      SizedBox(height: 12),
                      TextField(
                        controller: nameController,
                        decoration: InputDecoration(
                          labelText: 'Medicine Name',
                          hintText: "e.g. Paracetamol",
                          border: OutlineInputBorder(),
                        ),
                      ),
                      SizedBox(height: 12),
                      TextField(
                        controller: timeController,
                        decoration: InputDecoration(
                          labelText: 'Time (HH:MM)',
                          hintText: "e.g. 14:30",
                          border: OutlineInputBorder(),
                        ),
                        // keyboardType: TextInputType.datetime,
                      ),
                      SizedBox(height: 12),
                      TextField(
                        controller: noteController,
                        decoration: InputDecoration(
                          labelText: 'Notes',
                          hintText: "e.g. 5mg, take with food",
                          border: OutlineInputBorder(),
                        ),
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          TextButton(
                            onPressed: () => Navigator.of(context).pop(),
                            child: Text('Cancel'),
                          ),
                          ElevatedButton(
                            onPressed: () {
                              // نرخەکانی تێکست فیڵدەکان ئەکاتە ناو ڤاریەبڵەکان
                              // trim بەکاردێت بۆ لابردنی هەر سپەیسێکی زیادە لە سەرەتا و کۆتایی نووسینەکان
                              final name = nameController.text.trim();
                              final time = timeController.text.trim();
                              // ئەگەر ناوەکە بەتاڵ نەبوو و کاتەکە بەشێوەیەکی ڕاست نوسرابوو
                              // ئەوا بگەڕێرەوە بۆ شاشەی هۆمەکە پاش بانگ کردنەوەی میذۆدی زیادکردنەکە
                              if (name.isNotEmpty && time.contains(':')) {
                                _addMedicine(
                                  name,
                                  time,
                                  noteController.text.trim(),
                                );
                                Navigator.of(context).pop();
                              } else {

                                // 
                                // 
                                // 
                                // awa byka
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: Text(
                                      'Please enter valid name and time (HH:MM)',
                                    ),
                                  ),
                                );
                              }
                            },
                            child: Text('Save'),
                          ),
                        ],
                      ),
                      SizedBox(height: 8),
                    ],
                  ),
                );
              },
            );
          },
          //
          // ئایکۆنی FAB
          child: Icon(Icons.add, color: Colors.white),
        ),
      ),
    );
  }
}
