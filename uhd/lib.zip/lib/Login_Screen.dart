import 'package:flutter/material.dart';
import 'package:uhd/ContactUs.dart';
import 'package:uhd/Help.dart';
import 'package:uhd/Home.dart';
import 'package:uhd/Settings.dart';
import 'package:flutter/material.dart';

/// ================= LOGIN SCREEN =================

class LoginScreen1 extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {

  final _usernameController = TextEditingController();
  final _passwordController = TextEditingController();

  /// USERS LIST (FRONT-END ONLY)
  List<Map<String, String>> validUsers = [
    {"username": "Hana", "password": "1234", "email": "a@a.com"},
    {"username": "sarina", "password": "12", "email": "b@b.com"},
    {"username": "lare", "password": "123", "email": "c@c.com"},
  ];

  void _validateLogin() {
    String username = _usernameController.text.trim();
    String password = _passwordController.text.trim();

    bool isValidUser = validUsers.any(
      (user) =>
          user["username"] == username &&
          user["password"] == password,
    );

    if (isValidUser) {
      _showMessage("Login successful, $username!");
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => HomePage(userName: username),
        ),
      );
    } else {
      _showMessage("Invalid username or password!");
    }
  }

  void _showMessage(String message) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blueGrey[100],
      appBar: AppBar(
        title: Text("Medi Track"),
        backgroundColor: Colors.blueGrey[300],
      ),
      body: Center(
        child: Container(
          width: 300,
          padding: EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(color: Colors.grey, blurRadius: 8)
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: _usernameController,
                decoration: InputDecoration(
                  labelText: "Username",
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.person),
                ),
              ),
              SizedBox(height: 10),
              TextField(
                controller: _passwordController,
                obscureText: true,
                decoration: InputDecoration(
                  labelText: "Password",
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.lock),
                ),
              ),
              SizedBox(height: 15),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  ElevatedButton(
                    onPressed: _validateLogin,
                    child: Text("Login"),
                  ),
                  ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) =>
                              CreateAccountScreen(users: validUsers),
                        ),
                      );
                    },
                    child: Text("Create Account"),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// ================= CREATE ACCOUNT SCREEN =================

class CreateAccountScreen extends StatefulWidget {
  final List<Map<String, String>> users;
  CreateAccountScreen({required this.users});

  @override
  _CreateAccountScreenState createState() =>
      _CreateAccountScreenState();
}class _CreateAccountScreenState extends State<CreateAccountScreen> {
  final _usernameController = TextEditingController();
  final _passwordController = TextEditingController();
  final _emailController = TextEditingController();
  final _codeController = TextEditingController();

  String? verificationCode;
  bool emailVerified = false;

  void _sendCode() {
    String email = _emailController.text.trim();

    if (email.isEmpty || !email.contains('@')) {
      _showMessage("Enter a valid email");
      return;
    }

    verificationCode =
        (1000 + DateTime.now().millisecondsSinceEpoch % 9000)
            .toString();

    _showMessage("Verification code (demo): $verificationCode");
    setState(() {});
  }

  void _verifyCode() {
    if (_codeController.text.trim() == verificationCode) {
      emailVerified = true;
      _showMessage("Email verified successfully");
      setState(() {});
    } else {
      _showMessage("Wrong verification code");
    }
  }

  void _createAccount() {
    String username = _usernameController.text.trim();
    String password = _passwordController.text.trim();
    String email = _emailController.text.trim();

    if (username.isEmpty || password.isEmpty || email.isEmpty) {
      _showMessage("Please fill all fields");
      return;
    }

    if (!emailVerified) {
      _showMessage("Please verify your email first");
      return;
    }

    bool exists = widget.users.any(
      (user) => user["username"] == username,
    );

    if (exists) {
      _showMessage("Username already exists");
      return;
    }

    widget.users.add({
      "username": username,
      "password": password,
      "email": email,
    });

    _showMessage("Account created successfully");
    Navigator.pop(context);
  }

  void _showMessage(String message) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Create Account")),
      body: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          children: [
            TextField(
              controller: _usernameController,
              decoration: InputDecoration(labelText: "Username"),
            ),
            SizedBox(height: 10),
            TextField(
              controller: _passwordController,
              obscureText: true,
              decoration: InputDecoration(labelText: "Password"),
            ),
            SizedBox(height: 10),
            TextField(
              controller: _emailController,
              decoration: InputDecoration(
                labelText: "Email",
                suffixIcon: TextButton(
                  onPressed: _sendCode,
                  child: Text("Send Code"),
                ),
              ),
            ),
            SizedBox(height: 10),
            if (verificationCode != null && !emailVerified)
              TextField(
                controller: _codeController,
                decoration:
                    InputDecoration(labelText: "Verification Code"),
              ),
            if (verificationCode != null && !emailVerified)
              ElevatedButton(
                onPressed: _verifyCode,
                child: Text("Verify Email"),
              ),
            if (emailVerified)
              Text(
                "Email Verified ✔️",
                style: TextStyle(color: Colors.green),
              ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _createAccount,
              child: Text("Create Account"),
            ),
          ],
        ),
      ),
    );
  }
}

/// ================= HOME PAGE =================



class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenStatee extends State<LoginScreen> {
  final _usernameController = TextEditingController();
  final _passwordController = TextEditingController();

  String _result = "";

  // ئەگەر بتەوێت تەنها بە یوزەرێك لۆگین بکەیت ئەوا لە دێڕی ٢١ هەتاکو ٣٥ Uncomment بکە
  //وە ئەو بەشەی لە خوارەوە خستوومەتە نێوانی {{{}}} ئەم جۆرە کەوانەیەوە بیکە بە کۆمێنت

  // void _validateLogin() {
  // const String correctUsername = "Hana";
  // const String correctPassword = "1234";

  // if (_usernameController.text == correctUsername &&
  //     _passwordController.text == correctPassword) {
  //   _showMessage("Login successful, ${_usernameController.text}!");
  //   Navigator.pushReplacement(
  //     context,
  //     MaterialPageRoute(builder: (context) => HomePage()),
  //   );
  // } else {
  //   _showMessage("Invalid username or password!");
  // }
  // }
  //
  // ئەگەر بتەوێت زیاد لە یوزەرێکت هەبێت بەبێ هەبوونی دەیتابەیس
  //ئەوا وەك ئەم لیستە بکە
  // {{{
  void _validateLogin() {
    const List<Map<String, String>> validUsers = [
      {"username": "Hana", "password": "1234"},
      {"username": "sarina", "password": "12"},
      {"username": "lare", "password": "123"},
      {"username": "user3", "password": "pass3"},
      // .
      // .
      // .
      // Example users
    ];

    bool isValidUser = validUsers.any(
      (user) =>
          user["username"] == _usernameController.text &&
          user["password"] == _passwordController.text,
    );

    if (isValidUser) {
      _showMessage("Login successful, " + _usernameController.text + "!");
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => HomePage( userName: _usernameController.text)),
      );
    } else {
      _showMessage("Invalid username or password!");
    }
  }
  // }}}

  void _showMessage(String message) {
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  void dispose() {
    _usernameController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  // void _login() {
  //   setState(() {
  //     _result =
  //         "Username: ${_usernameController.text}\nPassword: ${_passwordController.text}";
  //   });
  //   _showMessage("Welcome ${_usernameController.text}!");
  // }

  // void _clear() {
  //   setState(() {
  //     _usernameController.clear();
  //     _passwordController.clear();
  //     _result = "";
  //   });
  //   _showMessage("Cleared!");
  // }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blueGrey[100],

      appBar: AppBar(
        backgroundColor: Colors.blueGrey[300],
        title: Center(child: Text("Medi Track")),
        actions: [
          IconButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => HelpPage()),
              );
            },
            icon: Icon(Icons.info_outline_rounded),
          ),
        ],
      ),

      body: Center(
        child: Container(
          width: 300,
          padding: EdgeInsets.all(20),
          margin: EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
            boxShadow: [BoxShadow(color: Colors.grey, blurRadius: 8)],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: _usernameController,
                decoration: InputDecoration(
                  labelText: "Username",
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.person),
                ),
              ),
              SizedBox(height: 10),
              TextField(
                controller: _passwordController,
                obscureText: true,
                decoration: InputDecoration(
                  labelText: "Password",
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.lock),
                ),
              ),
              SizedBox(height: 10),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  ElevatedButton(
                    onPressed: _validateLogin,
                    child: Text("Login"),
                  ),
                  
                  // OutlinedButton(onPressed: _clear, child: Text("Clear")),
                ],
              ),
              // Container(
              //   padding: EdgeInsets.all(10),
              //   decoration: BoxDecoration(
              //     color: Colors.greenAccent[100],
              //     borderRadius: BorderRadius.circular(8),
              //   ),
              //   child: Text(
              //     _result.isEmpty ? "Result will appear here" : _result,
              //     textAlign: TextAlign.center,
              //   ),
              // ),
            ],
          ),
        ),
      ),
    );
  }
}


void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: LoginScreen(),
    );
  }
}
